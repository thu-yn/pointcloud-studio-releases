# 第三方运行组件

0.4.1 新增 Ubuntu DEB：动态链接 Ubuntu 24.04 构建环境中的系统 Qt 6（最低 6.4），不把 Windows Qt DLL 打入 Linux 包。CPack 从实际 ELF 文件推导运行库依赖，并显式声明运行时加载的 SQLite 和平台插件；对应组件的版权与许可由 Ubuntu 系统包一同提供。下文 Qt 6.10.3 的物料清单和重建路径针对 Windows 包。

0.3.0 增加可选 OpenCL 1.2 API 整数属性过滤。仅延迟加载系统驱动提供的 OpenCL loader/ICD，不随包分发，不安装或更改驱动。小型ABI声明和内核独立编写，依据 [Khronos OpenCL 官方规范](https://registry.khronos.org/OpenCL/specs/unified/html/OpenCL_API.html)；没有复制第三方GPU算法实现。CPU主路径不依赖OpenCL，也不附带CUDA运行库。本机资格结果仅覆盖记录中的设备与属性算子。

本次 Windows 构建动态链接 Qt 6.10.3 的 Core、GUI、Widgets、OpenGL、OpenGLWidgets、Concurrent 和 SQL；SQLite 驱动由 Qt 的 QSQLITE 插件提供。程序没有加载 PointStudio 的专有 DLL。

打包脚本使用 Qt 官方 `windeployqt` 整理运行库和插件，并保留 Qt 提供的 `qtbase-6.10.3.spdx.json` 软件物料清单，其中有组件版本、来源、版权和许可标识。`third_party/licenses/` 保存 LGPLv3 和 GPLv3 原文。Qt 的内部第三方组件以对应物料清单及上游说明为准；这些组件不会因本项目引用而改变自身许可。

来源：

- [Qt 6.10 Licensing](https://doc.qt.io/qt-6.10/licensing.html)
- [Qt Windows Deployment](https://doc.qt.io/qt-6.10/windows-deployment.html)
- [Qt 6.10.3 源代码归档](https://download.qt.io/archive/qt/6.10/6.10.3/single/)
- [Qt qtbase 源代码](https://code.qt.io/cgit/qt/qtbase.git/tree/?h=v6.10.3)
- [GNU LGPLv3](https://www.gnu.org/licenses/lgpl-3.0.html)
- [GNU GPLv3](https://www.gnu.org/licenses/gpl-3.0.html)

当前包采用可替换的动态 Qt 运行库，不把 Qt 静态链接进应用。Microsoft C++ 运行库随 Windows 便携包以应用本地 DLL 方式整理；构建工具和 Qt 安装目录不会进入源代码仓库。

0.2.1 调研的 Open3D、small_gicp、nanoflann、PDAL、PROJ、PCL、fast_gicp 和 Cupoch 尚未加入运行依赖。它们的算法/平台/主项目许可及适配边界见 [ADR 0002](decisions/0002-open-source-and-optional-gpu.md)；集成前固定实际版本及完整依赖清单，不能把主项目许可直接扩展到全部传递依赖。当前包不附带 CUDA 计算运行库。

下载 Qt 6.10.3 源代码后可用相同 MSVC2022 x64 工具链和 Qt 官方构建说明重建 DLL。便携包通过 `qt.conf` 从本目录加载插件；需要调试或替换兼容 Qt 构建时，应整体替换匹配的 DLL/插件，保留应用源码构建结果。Qt 标准界面翻译包未包含在这个精简 SDK 中，应用自身中文界面已编译进程序。
